package org.example;


import rf.robson.REPL;

public class Main
{
    public static void main(String[] args)
    {
        REPL.start(new JavaLibrary());
    }
}
